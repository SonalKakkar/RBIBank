package enums;

public enum Context {
    EXPECTED_DATA;
}
